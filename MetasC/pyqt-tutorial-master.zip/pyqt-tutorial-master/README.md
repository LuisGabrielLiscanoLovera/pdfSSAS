# Tutorial GUI PyQT-5 
Esta serie de tutoriales contiene la información necesaria para introducirse en el desarrollo de Interfaces Gráficas de Usuario con la biblioteca PyQT 5 y el lenguaje de programación Python 3.x.

Más información en: [Tutoriales PyQT-5 Python 3.x](http://acodigo.blogspot.com/p/python.html)  